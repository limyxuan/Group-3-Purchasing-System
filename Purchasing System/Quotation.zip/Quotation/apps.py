from django.apps import AppConfig


class QuotationConfig(AppConfig):
    name = 'Quotation'
